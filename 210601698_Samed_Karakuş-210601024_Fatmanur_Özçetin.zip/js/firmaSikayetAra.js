<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

$(document).ready(function(){
    var element = $(".sikayetAra").val();
    
});